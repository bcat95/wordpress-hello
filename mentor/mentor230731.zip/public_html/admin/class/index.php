<?php
header("location:/");
die();
exit();