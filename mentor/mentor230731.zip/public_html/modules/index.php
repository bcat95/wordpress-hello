<?php 
header("location:/");
exit();