<?php
require_once(__DIR__ . '/../inc/includes.php');
// Set up API key
$API_KEY = $config->openai_api_key;