<?php 
header("Location: /");
die();