<?php
$host = 'localhost';
$user = 'ment_chatgpt';
$password = 'ePEIm@d#vwgCnkOH';
$dbname = 'ment_chatgpt';